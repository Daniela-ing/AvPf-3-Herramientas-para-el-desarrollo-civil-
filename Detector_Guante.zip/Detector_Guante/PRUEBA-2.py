import cv2
print(
	hasattr(
    	cv2,
    	'CascadeClassifier' 
	)
)
